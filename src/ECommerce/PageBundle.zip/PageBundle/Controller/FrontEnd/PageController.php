<?php

namespace ECommerce\PageBundle\Controller\FrontEnd;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use ECommerce\PageBundle\Entity\Page;
use ECommerce\PageBundle\Form\PageType;

/**
 * Page controller.
 *
 */
class PageController extends Controller
{

    public function menuAction()
    {
        $em = $this->getDoctrine()->getManager();
        $pages = $em->getRepository('ECommercePageBundle:Page')->findAll();

        return $this->render('ECommercePageBundle:FrontEnd/Page:menu.html.twig', array('pages' => $pages));
    }

}

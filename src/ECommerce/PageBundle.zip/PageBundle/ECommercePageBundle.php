<?php

namespace ECommerce\PageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ECommercePageBundle extends Bundle
{
}
